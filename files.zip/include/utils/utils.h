#ifndef UTILS_H
#define UTILS_H

#include <string>

// Utility function to format a greeting message
std::string formatGreeting(const std::string& name);

#endif // UTILS_H
